Hi!

Thank you for downloading my font. This font is SHAREWARE which means if you use it, you are obligated to pay for it. The cost is $10 US, payable via PayPal to fonts@fatcatfonts.com. Upon receipt of payment you will receive an unrestricted version which allows embedding in PDFs. 

For info on how to install the font, go here: http://www.dafont.com/faq.php After installing, you'll probably need to restart any open applications to use the font.

I hope you enjoy this font! If you use it for anything cool, please let me know and send me an example!!!

-Jen

http://www.fatcatfonts.com

fonts@fatcatfonts.com


----

11/24/2010
An up-to-date version of this readme can be found at fatcatfonts.com